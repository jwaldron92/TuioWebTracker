/*
 * Decompiled with CFR 0_115.
 */
package com.illposed.osc;

import com.illposed.osc.OSCPacket;
import com.illposed.osc.utility.OSCJavaToByteArrayConverter;
import java.math.BigInteger;
import java.util.Date;
import java.util.Enumeration;
import java.util.GregorianCalendar;
import java.util.Vector;

public class OSCBundle
extends OSCPacket {
    protected Date timestamp;
    protected Vector packets;
    public static final BigInteger SECONDS_FROM_1900_to_1970 = new BigInteger("2208988800");

    public OSCBundle() {
        this(null, GregorianCalendar.getInstance().getTime());
    }

    public OSCBundle(Date timestamp) {
        this(null, timestamp);
    }

    public OSCBundle(OSCPacket[] newPackets) {
        this(newPackets, GregorianCalendar.getInstance().getTime());
    }

    public OSCBundle(OSCPacket[] newPackets, Date newTimestamp) {
        if (newPackets != null) {
            this.packets = new Vector(newPackets.length);
            int i = 0;
            while (i < newPackets.length) {
                this.packets.add(newPackets[i]);
                ++i;
            }
        } else {
            this.packets = new Vector();
        }
        this.timestamp = newTimestamp;
        this.init();
    }

    public Date getTimestamp() {
        return this.timestamp;
    }

    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }

    public void addPacket(OSCPacket packet) {
        this.packets.add(packet);
    }

    public OSCPacket[] getPackets() {
        OSCPacket[] packetArray = new OSCPacket[this.packets.size()];
        this.packets.toArray(packetArray);
        return packetArray;
    }

    protected void computeTimeTagByteArray(OSCJavaToByteArrayConverter stream) {
        long millisecs = this.timestamp.getTime();
        long secsSince1970 = millisecs / 1000;
        long secs = secsSince1970 + SECONDS_FROM_1900_to_1970.longValue();
        long picosecs = (millisecs - secsSince1970 * 1000) * 1000;
        stream.write((int)secs);
        stream.write((int)picosecs);
    }

    protected void computeByteArray(OSCJavaToByteArrayConverter stream) {
        stream.write("#bundle");
        this.computeTimeTagByteArray(stream);
        Enumeration enm = this.packets.elements();
        while (enm.hasMoreElements()) {
            OSCPacket nextElement = (OSCPacket)enm.nextElement();
            byte[] packetBytes = nextElement.getByteArray();
            stream.write(packetBytes.length);
            stream.write(packetBytes);
        }
        this.byteArray = stream.toByteArray();
    }
}

