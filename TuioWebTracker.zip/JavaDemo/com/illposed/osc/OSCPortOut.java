/*
 * Decompiled with CFR 0_115.
 */
package com.illposed.osc;

import java.io.IOException;
import java.net.*;

public class OSCPortOut
extends OSCPort {
    protected InetAddress address;

    public OSCPortOut(InetAddress newAddress, int newPort) throws SocketException {
        this.socket = new DatagramSocket();
        this.address = newAddress;
        this.port = newPort;
    }

    public OSCPortOut(InetAddress newAddress) throws SocketException {
        this(newAddress, 57110);
    }

    public OSCPortOut() throws UnknownHostException, SocketException {
        this(InetAddress.getLocalHost(), 57110);
    }

    public void send(OSCPacket aPacket) throws IOException {
        byte[] byteArray = aPacket.getByteArray();
        DatagramPacket packet = new DatagramPacket(byteArray, byteArray.length, this.address, this.port);
        this.socket.send(packet);
    }
}

