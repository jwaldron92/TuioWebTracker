/*
 * Decompiled with CFR 0_115.
 */
package com.illposed.osc;

import java.net.DatagramSocket;

public abstract class OSCPort {
    protected DatagramSocket socket;
    protected int port;
    public static final int defaultSCOSCPort = 57110;
    public static final int defaultSCLangOSCPort = 57120;

    protected void finalize() throws Throwable {
        super.finalize();
        this.socket.close();
    }

    public void close() {
        this.socket.close();
    }
}

