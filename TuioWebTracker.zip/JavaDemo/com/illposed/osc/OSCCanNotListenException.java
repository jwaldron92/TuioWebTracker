/*
 * Decompiled with CFR 0_115.
 */
package com.illposed.osc;

public class OSCCanNotListenException
extends Exception {
    public OSCCanNotListenException() {
    }

    public OSCCanNotListenException(String message) {
        super(message);
    }
}

