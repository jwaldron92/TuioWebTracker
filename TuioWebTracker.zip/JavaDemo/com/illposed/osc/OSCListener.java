/*
 * Decompiled with CFR 0_115.
 */
package com.illposed.osc;

import com.illposed.osc.OSCMessage;
import java.util.Date;

public interface OSCListener {
    public void acceptMessage(Date var1, OSCMessage var2);
}

