# https://wiki.python.org/moin/UdpCommunication
# Project by Joe Waldron
#Usage: c:/Python27/python.exe client.py

#Use by receiving data from Websocket(UDP) in Unity, and sending the corresponding data to another websocket
# in HTML5. The Websocket should give
# Location
# Image file
# Background
# Aspect ratio Unity/ Phone size by logic in Python file: client.py or other

import socket
import struct

UDP_IP = "localhost"
UDP_PORT = 5050

sock = socket.socket(socket.AF_INET,  # Internet
                     socket.SOCK_DGRAM)  # UDP

try:
    sock.bind((UDP_IP, UDP_PORT))

    while True:
        datalen = 30
        data, addr = sock.recvfrom(datalen)  # buffer size is 1024 bytes
        print("received: ", data)
        print(len(data))
        if len(data) == datalen:
            message = struct.unpack("<llLLLLLh", data)
            t = message[0]
            latitude = message[1]
            # nord = message[2]
            # longitude = message[3]
            # east = message[4]
            # print("received message:", (t,latitude,nord,longitude,east), " - ", addr)
            for i in range(len(message)):
                print ':',
                print message[i],
            # print("received message:", (t,latitude), " - ", addr)
            print ""
finally:
    sock.close()