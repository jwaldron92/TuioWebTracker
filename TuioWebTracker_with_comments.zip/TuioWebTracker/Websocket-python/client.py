import socket



def sendToJava(data):
    print data
    client_socket.send(data + '\n')

if __name__ == "__main__":
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect(("localhost", 2000))