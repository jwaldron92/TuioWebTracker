'''
File: SimpleExampleSever.py
By Joseph Waldron
usage: With IDE. Do not use form command line because it will terminate the program

packet messages are in format "string,string"

SimpleExampleServer server
   Sends socket data to localhost:2000 for UDP transfer
   Receives websocket position from localhost:8000
   Recevies socket UDP data from Unity localhost:5050

The MIT License (MIT)
Copyright (c) 2013 Dave P.
'''

import signal, sys, ssl, socket
from SimpleWebSocketServer import WebSocket, SimpleWebSocketServer, SimpleSSLWebSocketServer
from optparse import OptionParser
import client

class SimpleEcho(WebSocket):
   """
   :parameter WebSocket is the interface from SimpleWebSocketServer. Receives over LAN on website
   Echos messages received and automatically sends to the Socket client
   """
   def handleMessage(self):
      print"got message", self.data
      self.sendMessage(self.data)
      client_socket.send(self.data + '\n')

   def handleConnected(self):
      pass

   def handleClose(self):
      pass

clients = []

if __name__ == "__main__":
   """
   __main__: starts a server from SimpleWebSocketServer and creates class
   SimpleEcho

   prints messages
   """

   parser = OptionParser(usage="usage: %prog [options]", version="%prog 1.0")
   parser.add_option("--host", default='', type='string', action="store", dest="host", help="hostname (localhost)")
   parser.add_option("--port", default=8000, type='int', action="store", dest="port", help="port (8000)")
   parser.add_option("--example", default='echo', type='string', action="store", dest="example", help="echo, chat")
   parser.add_option("--ssl", default=0, type='int', action="store", dest="ssl", help="ssl (1: on, 0: off (default))")
   parser.add_option("--cert", default='./cert.pem', type='string', action="store", dest="cert", help="cert (./cert.pem)")
   parser.add_option("--ver", default=ssl.PROTOCOL_TLSv1, type=int, action="store", dest="ver", help="ssl version")
   
   (options, args) = parser.parse_args()
   client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
   try:
      client_socket.connect(("localhost", 2500))
   except socket.error:
      print "Could not connect to the main frame for TUIO transfer, try again"
      sys.exit(1)
   cls = SimpleEcho                                                        #echos the websocket calls to client_socket

   server = SimpleWebSocketServer(options.host, options.port, cls)         #create new server on websock

   def close_sig_handler(signal, frame):
      server.close()
      sys.exit()

   signal.signal(signal.SIGINT, close_sig_handler)

   server.serveforever()

