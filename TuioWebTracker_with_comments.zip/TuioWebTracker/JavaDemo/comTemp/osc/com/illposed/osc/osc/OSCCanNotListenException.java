/*
 * Decompiled with CFR 0_115.
 */
package comTemp.osc.com.illposed.osc.osc;

public class OSCCanNotListenException
extends Exception {
    public OSCCanNotListenException() {
    }

    public OSCCanNotListenException(String message) {
        super(message);
    }
}

