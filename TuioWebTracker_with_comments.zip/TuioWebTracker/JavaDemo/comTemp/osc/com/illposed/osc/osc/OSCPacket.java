/*
 * Decompiled with CFR 0_115.
 */
package comTemp.osc.com.illposed.osc.osc;

import com.illposed.osc.utility.OSCJavaToByteArrayConverter;

public abstract class OSCPacket {
    protected boolean isByteArrayComputed;
    protected byte[] byteArray;

    protected void computeByteArray() {
        OSCJavaToByteArrayConverter stream = new OSCJavaToByteArrayConverter();
        this.computeByteArray(stream);
    }

    protected abstract void computeByteArray(OSCJavaToByteArrayConverter var1);

    public byte[] getByteArray() {
        if (!this.isByteArrayComputed) {
            this.computeByteArray();
        }
        return this.byteArray;
    }

    protected void init() {
    }
}

