/*
 * Decompiled with CFR 0_115.
 */
package comTemp.osc.com.illposed.osc.osc.utility;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.util.Enumeration;
import java.util.Vector;

public class OSCJavaToByteArrayConverter {
    protected ByteArrayOutputStream stream = new ByteArrayOutputStream();
    private byte[] intBytes = new byte[4];

    public void appendNullCharToAlignStream() {
        int mod = this.stream.size() % 4;
        int pad = 4 - mod;
        int i = 0;
        while (i < pad) {
            this.stream.write(0);
            ++i;
        }
    }

    public byte[] toByteArray() {
        return this.stream.toByteArray();
    }

    public void write(byte[] bytes) {
        this.writeBigEndToFourByteBoundry(bytes);
    }

    public void write(int i) {
        this.writeIntegerToByteArray(i);
    }

    public void write(Float f) {
        this.writeIntegerToByteArray(Float.floatToIntBits(f.floatValue()));
    }

    public void write(Integer i) {
        this.writeIntegerToByteArray(i);
    }

    public void write(String str) {
        this.writeLittleEndToFourByteBoundry(str.getBytes());
    }

    public void write(char c) {
        this.stream.write(c);
    }

    public void write(Object anObject) {
        if (anObject == null) {
            return;
        }
        if (anObject instanceof Float) {
            this.write((Float)anObject);
            return;
        }
        if (anObject instanceof String) {
            this.write((String)anObject);
            return;
        }
        if (anObject instanceof Integer) {
            this.write((Integer)anObject);
            return;
        }
    }

    public void writeType(Class c) {
        if (Integer.class.equals(c)) {
            this.stream.write(105);
            return;
        }
        if (BigInteger.class.equals(c)) {
            this.stream.write(104);
            return;
        }
        if (Float.class.equals(c)) {
            this.stream.write(102);
            return;
        }
        if (Double.class.equals(c)) {
            this.stream.write(100);
            return;
        }
        if (String.class.equals(c)) {
            this.stream.write(115);
            return;
        }
        if (Character.class.equals(c)) {
            this.stream.write(99);
            return;
        }
    }

    public void writeTypesArray(Object[] array) {
        int i = 0;
        while (i < array.length) {
            if (array[i] != null) {
                if (array[i].getClass().isArray()) {
                    this.stream.write(91);
                    this.writeTypesArray((Object[])array[i]);
                    this.stream.write(93);
                } else if (Boolean.TRUE.equals(array[i])) {
                    this.stream.write(84);
                } else if (Boolean.FALSE.equals(array[i])) {
                    this.stream.write(70);
                } else {
                    this.writeType(array[i].getClass());
                }
            }
            ++i;
        }
        this.appendNullCharToAlignStream();
    }

    public void writeTypes(Vector vector) {
        Enumeration enm = vector.elements();
        while (enm.hasMoreElements()) {
            Object nextObject = enm.nextElement();
            if (nextObject == null) continue;
            if (nextObject.getClass().isArray()) {
                this.stream.write(91);
                this.writeTypesArray((Object[])nextObject);
                this.stream.write(93);
                continue;
            }
            if (Boolean.TRUE.equals(nextObject)) {
                this.stream.write(84);
                continue;
            }
            if (Boolean.FALSE.equals(nextObject)) {
                this.stream.write(70);
                continue;
            }
            this.writeType(nextObject.getClass());
        }
        this.appendNullCharToAlignStream();
    }

    private void writeIntegerToByteArray(int value) {
        byte[] intBytes = new byte[4];
        intBytes[3] = (byte)value;
        intBytes[2] = (byte)(value >>>= 8);
        intBytes[1] = (byte)(value >>>= 8);
        intBytes[0] = (byte)(value >>>= 8);
        try {
            this.stream.write(intBytes);
        }
        catch (IOException e) {
            throw new RuntimeException("You're screwed: IOException writing to a ByteArrayOutputStream");
        }
    }

    private void writeBigEndToFourByteBoundry(byte[] bytes) {
        int mod = bytes.length % 4;
        if (mod == 0) {
            try {
                this.stream.write(bytes);
            }
            catch (IOException e) {
                throw new RuntimeException("You're screwed: IOException writing to a ByteArrayOutputStream");
            }
            return;
        }
        int pad = 4 - mod;
        byte[] newBytes = new byte[pad + bytes.length];
        System.arraycopy(bytes, 0, newBytes, pad, bytes.length);
        try {
            this.stream.write(newBytes);
        }
        catch (IOException e) {
            throw new RuntimeException("You're screwed: IOException writing to a ByteArrayOutputStream");
        }
    }

    private void writeLittleEndToFourByteBoundry(byte[] bytes) {
        int mod = bytes.length % 4;
        if (mod == 4) {
            try {
                this.stream.write(bytes);
            }
            catch (IOException e) {
                throw new RuntimeException("You're screwed: IOException writing to a ByteArrayOutputStream");
            }
            return;
        }
        int pad = 4 - mod;
        byte[] newBytes = new byte[pad + bytes.length];
        System.arraycopy(bytes, 0, newBytes, 0, bytes.length);
        try {
            this.stream.write(newBytes);
        }
        catch (IOException e) {
            throw new RuntimeException("You're screwed: IOException writing to a ByteArrayOutputStream");
        }
    }
}

