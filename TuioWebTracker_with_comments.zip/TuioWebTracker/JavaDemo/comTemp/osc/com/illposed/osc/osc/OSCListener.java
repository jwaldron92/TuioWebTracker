/*
 * Decompiled with CFR 0_115.
 */
package comTemp.osc.com.illposed.osc.osc;

import com.illposed.osc.OSCMessage;

import java.util.Date;

public interface OSCListener {
    public void acceptMessage(Date var1, OSCMessage var2);
}

