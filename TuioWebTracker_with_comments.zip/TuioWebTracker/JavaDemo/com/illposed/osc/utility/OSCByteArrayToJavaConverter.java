/*
 * Decompiled with CFR 0_115.
 */
package com.illposed.osc.utility;

import com.illposed.osc.OSCBundle;
import com.illposed.osc.OSCMessage;
import com.illposed.osc.OSCPacket;
import java.math.BigInteger;
import java.util.Date;

public class OSCByteArrayToJavaConverter {
    byte[] bytes;
    int bytesLength;
    int streamPosition;
    private byte[] intBytes = new byte[4];
    private byte[] floatBytes = new byte[4];
    private byte[] secondBytes = new byte[8];
    private byte[] picosecBytes = new byte[8];

    public OSCPacket convert(byte[] byteArray, int bytesLength) {
        this.bytes = byteArray;
        this.bytesLength = bytesLength;
        this.streamPosition = 0;
        if (this.isBundle()) {
            return this.convertBundle();
        }
        return this.convertMessage();
    }

    private boolean isBundle() {
        String bytesAsString = new String(this.bytes, 0, 7);
        return bytesAsString.startsWith("#bundle");
    }

    private OSCBundle convertBundle() {
        this.streamPosition = 8;
        Date timestamp = this.readTimeTag();
        OSCBundle bundle = new OSCBundle(timestamp);
        OSCByteArrayToJavaConverter myConverter = new OSCByteArrayToJavaConverter();
        while (this.streamPosition < this.bytesLength) {
            int packetLength = (Integer)this.readInteger();
            byte[] packetBytes = new byte[packetLength];
            System.arraycopy(this.bytes, this.streamPosition, packetBytes, 0, packetLength);
            this.streamPosition += packetLength;
            OSCPacket packet = myConverter.convert(packetBytes, packetLength);
            bundle.addPacket(packet);
        }
        return bundle;
    }

    private OSCMessage convertMessage() {
        OSCMessage message = new OSCMessage();
        message.setAddress(this.readString());
        char[] types = this.readTypes();
        if (types == null) {
            return message;
        }
        this.moveToFourByteBoundry();
        int i = 0;
        while (i < types.length) {
            if ('[' == types[i]) {
                message.addArgument(this.readArray(types, i));
                while (']' != types[i]) {
                    ++i;
                }
            } else {
                message.addArgument(this.readArgument(types[i]));
            }
            ++i;
        }
        return message;
    }

    private String readString() {
        int strLen = this.lengthOfCurrentString();
        char[] stringChars = new char[strLen];
        int i = 0;
        while (i < strLen) {
            stringChars[i] = this.bytes[this.streamPosition++];
            ++i;
        }
        this.moveToFourByteBoundry();
        return new String(stringChars);
    }

    private char[] readTypes() {
        if (this.bytes[this.streamPosition] != 44) {
            return null;
        }
        ++this.streamPosition;
        int typesLen = this.lengthOfCurrentString();
        if (typesLen == 0) {
            return null;
        }
        char[] typesChars = new char[typesLen];
        int i = 0;
        while (i < typesLen) {
            typesChars[i] = this.bytes[this.streamPosition++];
            ++i;
        }
        return typesChars;
    }

    private Object readArgument(char c) {
        switch (c) {
            case 'i': {
                return this.readInteger();
            }
            case 'h': {
                return this.readBigInteger();
            }
            case 'f': {
                return this.readFloat();
            }
            case 'd': {
                return this.readDouble();
            }
            case 's': {
                return this.readString();
            }
            case 'c': {
                return this.readChar();
            }
            case 'T': {
                return Boolean.TRUE;
            }
            case 'F': {
                return Boolean.FALSE;
            }
        }
        return null;
    }

    private Object readChar() {
        return new Character(this.bytes[this.streamPosition++]);
    }

    private Object readDouble() {
        return this.readFloat();
    }

    private Object readFloat() {
        this.floatBytes[0] = this.bytes[this.streamPosition++];
        this.floatBytes[1] = this.bytes[this.streamPosition++];
        this.floatBytes[2] = this.bytes[this.streamPosition++];
        this.floatBytes[3] = this.bytes[this.streamPosition++];
        int floatBits = (this.floatBytes[3] & 255) + ((this.floatBytes[2] & 255) << 8) + ((this.floatBytes[1] & 255) << 16) + ((this.floatBytes[0] & 255) << 24);
        return new Float(Float.intBitsToFloat(floatBits));
    }

    private Object readBigInteger() {
        this.intBytes[0] = this.bytes[this.streamPosition++];
        this.intBytes[1] = this.bytes[this.streamPosition++];
        this.intBytes[2] = this.bytes[this.streamPosition++];
        this.intBytes[3] = this.bytes[this.streamPosition++];
        int intBits = (this.intBytes[3] & 255) + ((this.intBytes[2] & 255) << 8) + ((this.intBytes[1] & 255) << 16) + ((this.intBytes[0] & 255) << 24);
        return new Integer(intBits);
    }

    private Object readInteger() {
        this.intBytes[0] = this.bytes[this.streamPosition++];
        this.intBytes[1] = this.bytes[this.streamPosition++];
        this.intBytes[2] = this.bytes[this.streamPosition++];
        this.intBytes[3] = this.bytes[this.streamPosition++];
        int intBits = (this.intBytes[3] & 255) + ((this.intBytes[2] & 255) << 8) + ((this.intBytes[1] & 255) << 16) + ((this.intBytes[0] & 255) << 24);
        return new Integer(intBits);
    }

    private Date readTimeTag() {
        System.arraycopy(this.bytes, this.streamPosition, this.secondBytes, 4, 4);
        this.streamPosition += 4;
        System.arraycopy(this.bytes, this.streamPosition, this.picosecBytes, 4, 4);
        this.streamPosition += 4;
        BigInteger secsSince1900 = new BigInteger(this.secondBytes);
        long secsSince1970 = secsSince1900.longValue() - OSCBundle.SECONDS_FROM_1900_to_1970.longValue();
        if (secsSince1970 < 0) {
            secsSince1970 = 0;
        }
        BigInteger picosecs = new BigInteger(this.picosecBytes);
        long millisecs = secsSince1970 * 1000 + picosecs.longValue() / 1000;
        return new Date(millisecs);
    }

    private Object[] readArray(char[] types, int i) {
        int arrayLen = 0;
        while (types[i + arrayLen] != ']') {
            ++arrayLen;
        }
        Object[] array = new Object[arrayLen];
        int j = 0;
        while (i < arrayLen) {
            array[j] = this.readArgument(types[i + j]);
            ++j;
        }
        return array;
    }

    private int lengthOfCurrentString() {
        int i = 0;
        while (this.bytes[this.streamPosition + i] != 0) {
            ++i;
        }
        return i;
    }

    private void moveToFourByteBoundry() {
        int mod = this.streamPosition % 4;
        this.streamPosition += 4 - mod;
    }
}

