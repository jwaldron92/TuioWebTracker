package com.company;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

public class Main {

    public static void main(String[] args) {
        String fromclient = null;

        ServerSocket Server = null;
        try {
            Server = new ServerSocket(2000);
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println ("TCPServer Waiting for client on port 5000");

        while(true)
        {
            Socket connected = null;
            try {
                connected = Server.accept();
            } catch (IOException e) {
                e.printStackTrace();
            }
            System.out.println( " THE CLIENT"+" "+ connected.getInetAddress() +":"+connected.getPort()+" IS CONNECTED ");

            BufferedReader inFromClient = null;
            try {
                inFromClient = new BufferedReader(new InputStreamReader(connected.getInputStream()));
            } catch (IOException e) {
                e.printStackTrace();
            }

            while ( true )
            {

                try {
                    fromclient = inFromClient.readLine();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                if (fromclient != null) {

                    if (fromclient.equals("q") || fromclient.equals("Q")) {
                        System.out.println("received q");
                        try {
                            connected.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        break;
                    } else {
                        System.out.println("RECIEVED:" + fromclient);
                    }
                }
            }
        }
    }
}
